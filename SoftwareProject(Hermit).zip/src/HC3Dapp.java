/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author tub82740
 */
public class HC3Dapp {
    
    
    public static void main(String[] args){
        WelcomePage welcome = new WelcomePage();
        welcome.setVisible(true);
       
        
    }
}
